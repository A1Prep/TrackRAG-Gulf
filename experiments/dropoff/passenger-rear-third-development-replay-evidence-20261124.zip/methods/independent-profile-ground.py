"""AI review: synthetic acceptance/obstruction controls. No field photos, passenger words or reference points."""
import hashlib,json
from io import BytesIO
from pathlib import Path
import numpy as np
from PIL import Image
from trackrag.dropoff import vehicle_profile_ground as model

def solve(mode):
    w,h=600,400
    label=np.full((h,w),13,dtype=np.uint8)
    label[:,220:]=10
    rgb=np.where((label==10)[:,:,None],np.uint8([152,130,104]),np.uint8([56,66,72]))
    anchor=[370,130,510,195];companion=[213,138,285,177]
    boxes=[anchor,companion]
    for x0,y0,x1,y1 in boxes:
        label[y0:y1,x0:x1]=55;rgb[y0:y1,x0:x1]=[31,37,41]
    if mode in ('raised-strip-under-companion','raised-strip-under-both'):
        for box in ([companion] if mode.endswith('companion') else boxes):
            x0,y0,x1,y1=box
            label[y1:y1+7,x0:x1]=2
            rgb[y1:y1+3,x0:x1]=[215,209,197]
            rgb[y1+3:y1+7,x0:x1]=[55,51,50]
    if mode in ('kerb','short-walk-through','vehicle-opening'):
        label[:,216:223]=2
        rgb[:,216:220]=[211,205,192];rgb[:,220:223]=[55,50,46]
        free={'kerb':0,'short-walk-through':17,'vehicle-opening':75}[mode]
        lo,hi=200-free//2,200+(free+1)//2
        if free:
            label[lo:hi,216:220]=13;label[lo:hi,220:223]=10
            rgb[lo:hi,216:220]=[56,66,72];rgb[lo:hi,220:223]=[152,130,104]
    if mode=='road-only':
        label[label==10]=13
    if mode=='occupied':
        boxes.append([333,190,352,211])
    original=Image.fromarray(rgb.astype(np.uint8))
    stream=BytesIO();original.save(stream,format='PNG');raw=stream.getvalue()
    scene={'source':'predicted','frame':{'recording_id':'synthetic-profile-review','frame_id':2,'width':w,'height':h},
           'provenance':{'image_sha256':hashlib.sha256(raw).hexdigest()},
           'tracks':[{'frame_id':2,'track_id':i,'class_name':'car','bbox_xyxy':v} for i,v in enumerate(boxes,1)]}
    spec={'track_id':1,'class':'car','box':anchor,'ground':None}
    return [x['point'] for x in model.candidates(raw,label,scene,spec,facing='SIDE',tail='LEFT')]
if __name__=='__main__':
    vals={k:solve(k) for k in ('clear','road-only','occupied','raised-strip-under-companion','raised-strip-under-both','kerb','short-walk-through','vehicle-opening')}
    print(json.dumps(vals,indent=2))
