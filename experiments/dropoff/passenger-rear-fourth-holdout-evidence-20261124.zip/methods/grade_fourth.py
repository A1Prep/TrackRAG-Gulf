"""Replay the final six UAE driving-photo tests from complete browser responses and frozen native ground truth."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

HERE = Path(__file__).resolve().parent
sys.path.append(str(HERE.parent / "third"))
from grade_live import PUBLIC_SOURCE_FIELDS, grade_row, stats, utc


def digest(content):
    return hashlib.sha256(content).hexdigest()


SEAL_SHA = "42b54ef6bfd0705035c101447532af587af715b5d0a0cdd95cf0ac0ce136d275"
NAMES = {"sources": "fourth-sources.json", "requests": "fourth-requests.json", "reference": "fourth-reference.json", "road_taps": "fourth-taps.json", "seal": "fourth-seal.json"}
ZPATH = {"sources": "public_sources.json", "requests": "blind_inputs/fourth-requests.json", "reference": "independent_reference/fourth-reference.json",
         "road_taps": "blind_inputs/fourth-taps.json", "seal": "independent_reference/fourth-seal.json"}


def grade(content, decision, read_field, *, full_sources):
    b = json.loads(content)
    assert b.get("finished_utc") and re.fullmatch("[0-9a-f]{40}", decision) and b.get("candidate") == decision
    assert len(b["rows"]) == 12
    observed = {(r["id"], r["task"]) for r in b["rows"]}
    assert len(observed) == 12
    seal = json.loads(read_field("seal"))
    assert seal["case_count"] == 6 and seal["sha256"]["reference"] == SEAL_SHA
    assert utc(seal["frozen_utc"]) < utc(b["finished_utc"])
    for key in ("requests", "road_taps", "reference"):
        assert digest(read_field(key)) == seal["sha256"][key]
    assert b["requests_sha256"] == seal["sha256"]["requests"] and b["taps_sha256"] == seal["sha256"]["road_taps"]
    gold = {g["id"]: g for g in json.loads(read_field("reference"))["cases"]}
    assert observed == {(k, t) for k in gold for t in ("natural", "lane")}
    source_data = read_field("sources")
    if full_sources:
        assert digest(source_data) == seal["sha256"]["sources"]
        sources = json.loads(source_data)["sources"]
    else:
        sources = json.loads(source_data)
    for row in sources:
        assert all(row[k] == gold[row["id"]][k] for k in ("recording_id", "frame_id", "sha256", "size"))
    assert {s["id"] for s in sources} == set(gold)
    rows = [dict(grade_row(r, gold[r["id"]]), enrollment_commit=r.get("release_commit")) for r in b["rows"]]
    groups = {}
    for task in ("natural", "lane"):
        subset = [r for r in rows if r["task"] == task]
        subset_clear = [r for r in subset if r["eligible"]]
        groups[task] = {
            "n": len(subset), "eligible": len(subset_clear), "ineligible": len(subset) - len(subset_clear),
            "outcomes": dict(Counter(r["outcome"] for r in subset)),
            "vehicle_alignment": dict(Counter(r["anchor"]["classification"] for r in subset)),
            "eligible_vehicle_alignment": dict(Counter(r["anchor"]["classification"] for r in subset_clear)),
            "correct_direct_and_unique_body": sum(r["outcome"] == "direct_correct" and r["anchor"]["classification"] == "unique_correct" for r in subset),
            "correct_direct_and_body_present": sum(r["outcome"] == "direct_correct" and r["anchor"]["classification"] in ("unique_correct", "correct_among_several") for r in subset),
            "separately_selectable_ground_choices": sum(len(r["alternatives"]) for r in subset),
            "correct_choice_amid_wrong_choices": sum(
                r["outcome"] == "alternative_available" and any(not q["strictly_inside"] for q in r["alternatives"]) for r in subset
            ),
            "explicit_saves": sum(r["explicit_save"] for r in subset),
            "visible_ms": stats([r["visible_ms"] for r in subset if r["visible_ms"] is not None]),
            "browser_errors": sum(len(r["browser_errors"]) for r in subset),
        }
    return {
        "decision_commit": decision, "frozen_utc": seal["frozen_utc"], "browser_completed_utc": b["finished_utc"],
        "sealed_source_and_reference": seal["sha256"], "browser_observations_sha256": digest(content),
        "population": "Six public KartaView UAE driver-view photographs on six previously unused recording sequences and capture days. Three eligible ground regions and three negative cases were chosen by an independent AI visual reviewer before model or detector outputs. No human labels, real driving intervention or legal clearance assessment.",
        "criteria": "The same numeric scorer as the third field is reused. A direct correct answer must put its explicit, persisted native point strictly inside a separately frozen polygon. A vehicle-only outline (IoU >= 0.50), a list of selectable alternate locations, a wrong-region pin, a completed clarification and a browser/model failure are separate. Each independent through-lane tap is scored in a clean session. Browser wall time excludes source preparation and human saving time.",
        "summary": groups, "rows": rows,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--observations", type=Path)
    parser.add_argument("--decision")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--replay", type=Path)
    args = parser.parse_args()
    if args.replay:
        with zipfile.ZipFile(args.replay) as z:
            content = z.read("browser_outputs/observations.json")
            report = grade(content, json.loads(content)["candidate"], lambda key:z.read(ZPATH[key]), full_sources=False)
        print(json.dumps(report))
        return
    assert args.observations and args.decision and args.output and args.archive
    read_field = lambda key:(HERE / NAMES[key]).read_bytes()
    obs = args.observations.read_bytes()
    report = grade(obs, args.decision, read_field, full_sources=True)
    args.archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        z.writestr("browser_outputs/observations.json", obs)
        sources = [{k:r[k] for k in PUBLIC_SOURCE_FIELDS} for r in json.loads(read_field("sources"))["sources"]]
        z.writestr(ZPATH["sources"], json.dumps(sources, indent=2, ensure_ascii=False))
        for key in ("requests","road_taps","reference","seal"):
            z.writestr(ZPATH[key], read_field(key))
        z.write(HERE.parents[1] / "field-browser.cjs", "methods/field-browser.cjs")
        z.write(HERE.parent / "grade_browser.py", "methods/grade_browser.py")
        z.write(HERE.parent / "third" / "grade_live.py", "methods/grade_live.py")
        z.write(Path(__file__), "methods/grade_fourth.py")
    report.update({
        "evidence_archive":args.archive.name, "evidence_archive_sha256":digest(args.archive.read_bytes()),
        "reproduce":"Extract the three Python files under methods together and run python grade_fourth.py --replay <archive.zip>. No model or source image is required to reproduce the scores.",
    })
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2,ensure_ascii=False)+"\n",encoding="utf8")
    print(json.dumps(report["summary"]))


if __name__ == "__main__":
    main()
