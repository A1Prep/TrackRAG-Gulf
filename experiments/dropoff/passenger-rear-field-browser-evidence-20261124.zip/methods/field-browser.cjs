const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const {createHash} = require('node:crypto');
const {chromium} = require('playwright');
const [port, file, tapsFile, out, candidate] = process.argv.slice(2);
const base = `http://127.0.0.1:${Number(port)}`;
const hash = data => createHash('sha256').update(data).digest('hex');
const raw = fs.readFileSync(file), tapsRaw = fs.readFileSync(tapsFile);
const cases = JSON.parse(raw).requests, taps = new Map(JSON.parse(tapsRaw).map(c => [c.id, c.lane_xy]));
assert(/^[0-9a-f]{40}$/.test(candidate));
fs.mkdirSync(out, {recursive: true});
const dest = path.join(out, 'observations.json');
const recorded = fs.existsSync(dest) ? JSON.parse(fs.readFileSync(dest)) : {candidate, requests_sha256:hash(raw), taps_sha256:hash(tapsRaw), rows:[]};
assert.equal(recorded.candidate, candidate); assert.equal(recorded.requests_sha256, hash(raw));
const save = () => fs.writeFileSync(dest, JSON.stringify(recorded, null, 2)+'\n');
async function run(page, item, task, frame, row) {
  page.setDefaultTimeout(16000);
  await page.route('**/*', r => new URL(r.request().url()).hostname === '127.0.0.1' ? r.continue() : r.abort());
  page.on('pageerror', e => row.browser_errors.push(e.message));
  const [start] = await Promise.all([page.waitForResponse(r => new URL(r.url()).pathname === '/api/sessions' && r.request().method() === 'POST'), page.goto(base+'/?scene='+frame.key, {waitUntil:'domcontentloaded'})]);
  const session = (await start.json()).session;
  const read = async () => (await (await page.request.get(base+'/api/sessions/'+session)).json()).view;
  assert(session);
  await page.waitForFunction(() => document.querySelector('#frame').naturalWidth > 0 && !document.querySelector('#scene').disabled);
  const photo = await page.request.get(new URL(await page.locator('#frame').getAttribute('src'), base).href);
  assert.equal(hash(await photo.body()), item.sha256);
  await page.locator('#instruction').fill(item.words);
  let t;
  if(task === 'natural') {
    t = performance.now();
    await page.locator('#submit').click();
    await page.waitForFunction(() => ['proposed','clarify','error'].includes(document.querySelector('#destination-panel').dataset.state), null, {timeout:50000});
  } else {
    if(task==='override') {
      await page.locator('#submit').click();
      await page.waitForFunction(()=>['proposed','clarify','error'].includes(document.querySelector('#destination-panel').dataset.state),null,{timeout:50000});
      const current=await read();
      if(current.state!=='proposed'){row.terminal='no_initial_proposal';return;}
      assert(current.proposal_id); row.original_point=current.result.destination_point_xy;
      await page.locator('#draw').click();
    } else await page.locator('#submit-area').click();
    const xy = taps.get(item.id), canvas = page.locator('#overlay');
    await page.locator('#draw-tools').waitFor(); await canvas.scrollIntoViewIfNeeded();
    const rect = await canvas.boundingBox();
    await canvas.click({position:{x:xy[0]*rect.width/frame.width,y:xy[1]*rect.height/frame.height}});
    t = performance.now();
    const [res] = await Promise.all([page.waitForResponse(r => new URL(r.url()).pathname.endsWith('/area')), page.locator('#use-box').click()]);
    const q = res.request().postDataJSON().box;
    row.actual_tap = [(q[0]+q[2])/2,(q[1]+q[3])/2];
    assert(Math.hypot(row.actual_tap[0]-xy[0],row.actual_tap[1]-xy[1]) < .004*Math.hypot(frame.width,frame.height));
    const state = (await res.json()).view.state;
    await page.waitForFunction(state => document.querySelector('#destination-panel').dataset.state === ({proposed:'proposed',needs_clarification:'clarify',error:'error',insufficient_visual_evidence:'clarify'}[state]),state);
  }
  row.visible_ms = Math.round(performance.now()-t);
  const view = await read(); assert.equal(view.image_sha256,item.sha256); assert.equal(view.frame_id,item.frame_id);
  row.state=view.state; row.result=view.result; row.reference_kind=view.reference_kind; row.choices=view.bay_choices || [];
  row.vehicle=view.rear_vehicle; row.label=view.bay_outline?.extent; row.error=view.error;
  row.actor=view.selected_by; row.proposal=!!view.proposal_id;
  row.heading=await page.locator('#destination-title').innerText(); row.message=await page.locator('#status').innerText();
  row.save_visible=await page.locator('#confirm').isVisible(); row.legend=await page.locator('#legend').innerText();
  await page.screenshot({path:path.join(out,item.id+'-'+task+'.png'),fullPage:true});
  if(task === 'natural' && row.state === 'proposed') {
    assert(row.save_visible && row.proposal && !row.choices.length);
    await page.locator('#confirm').click();
    await page.waitForFunction(() => document.querySelector('#destination-panel').dataset.state === 'confirmed');
    const confirmed=await read(); assert.deepEqual(confirmed.result.destination_point_xy,row.result.destination_point_xy);
    row.save_verified=true;
  }
  row.terminal='completed';
}
(async()=>{
  const catalog=(await (await fetch(base+'/api/scenes')).json()).scenes;
  const browser=await chromium.launch({executablePath:process.env.PASSENGER_CHROMIUM,headless:true,args:['--disable-gpu']});
  const requestedTasks = (process.env.FIELD_TASKS || 'natural,lane').split(',');
  assert(requestedTasks.every(t => ['natural','lane','override'].includes(t)));
  try {for(const task of requestedTasks) for(const c of cases) {
    if(recorded.rows.some(r => r.id===c.id && r.task===task))continue;
    const frame=catalog.find(f=>f.recording_id===c.recording_id && f.frame_id===c.frame_id);
    assert(frame, c.id+' missing from served catalog');
    const page=await browser.newPage({viewport:{width:1390,height:870}});
    const row={id:c.id,task,scene:frame.key,sha256:c.sha256,browser_errors:[]};
    try {await run(page,c,task,frame,row);} catch(e) {row.terminal='error';row.problem=String(e.message).slice(0,350);}
    await page.close(); recorded.rows.push(row);save();console.log(c.id,task,row.state||row.terminal,row.visible_ms||0);
  }} finally {await browser.close();} recorded.finished_utc=new Date().toISOString();save();
})().catch(e=>{console.error(e);process.exitCode=1});
