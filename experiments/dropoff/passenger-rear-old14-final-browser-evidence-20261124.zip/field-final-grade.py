"""Grade only the two previously released original study arms from their actual fresh sessions."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import statistics
import sys
from zipfile import ZIP_DEFLATED, ZipFile


base = Path(__file__).resolve().parent
sys.path.insert(0, str(base/'field'))
from grade_browser import body_measure, polygon_distance


def grades(cohort, path, commit):
    source = base/'field'
    trial = json.loads(path.read_bytes())
    assert trial['candidate'] == commit
    gold_path = source/(cohort+'-reference.json')
    original = gold_path.read_bytes()
    locked = json.loads((source/(cohort+'-seal.json')).read_bytes())
    assert sha256(original).hexdigest() == locked['sha256']['reference']
    assert sha256((source/(cohort+'-requests.json')).read_bytes()).hexdigest() == trial['requests_sha256']
    assert sha256((source/(cohort+'-taps.json')).read_bytes()).hexdigest() == trial['taps_sha256']
    grades = {r['id']:r for r in json.loads(original)['cases']}
    scored = []
    for row in trial['rows']:
        g = grades[row['id']]
        assert row['sha256'] == g['sha256']
        result, choices = (row.get('result') or {}), row.get('choices', [])
        pin = result.get('destination_point_xy')
        def inside(p):
            return bool(p and any(polygon_distance(p, poly)>0 for poly in g['ground_polygons_xy']))
        options = [c['center_xy'] for c in choices]
        offer = row.get('state') == 'proposed' and row['proposal'] and row['save_visible'] and pin
        withheld = (row.get('state') in {'needs_clarification','insufficient_visual_evidence'} and
                    not pin and not options and not row.get('proposal') and not row.get('save_visible'))
        if row['terminal'] == 'no_initial_proposal':
            grade = 'no_offer_to_override'
        elif row['terminal'] != 'completed' or row.get('error') or row.get('state') == 'error':
            grade = 'operational_error'
        elif row['task'] in {'override', 'lane'}:
            grade = ('lane_withheld' if withheld else 'lane_falsely_offered' if offer or options else 'other')
            if row['task'] == 'override' and (row.get('previous_offer_rejected') is not True):
                grade = 'superseded_offer_not_rejected'
        elif offer:
            grade = 'correct_direct' if inside(pin) else ('wrong_direct_on_positive' if g['eligible'] else 'false_direct_on_negative')
        elif options:
            grade = ('correct_choices_only' if all(map(inside,options)) else
                     'correct_and_wrong_choices' if any(map(inside,options)) else
                     'wrong_choices_on_positive' if g['eligible'] else 'false_choices_on_negative')
        elif withheld:
            grade = 'opportunity_withheld' if g['eligible'] else 'negative_withheld'
        else:
            grade = 'unexpected_state'
        if not row.get('browser_errors') and grade in {'correct_direct','correct_choices_only'}:
            assert row['save_verified'] and inside(row['saved_point'])
        score = {'id':g['id'], 'task':row['task'], 'eligible':g['eligible'], 'grade':grade,
                 'ms':row.get('visible_ms'), 'measured_body':body_measure(result.get('anchor_boxes_xyxy') or [],g['anchor_boxes_xyxy'])['classification'],
                 'point':pin, 'offered_centres':options, 'first_choice_save_verified':bool(row.get('save_verified')),
                 'separate_offers':len(options),'reference_only':row.get('reference_kind'), 'page_errors':row.get('browser_errors') or []}
        if row['task']=='override' and row.get('stale_offer_status'):
            score['stale_offer_http_status']=row['stale_offer_status']
        if row.get('problem') or row.get('error'):
            score['error']=row.get('problem') or row.get('error')
        scored.append(score)
    assert {(r['id'],r['task']) for r in scored} == {(i,t) for i in grades for t in ('natural','lane','override')}
    summary = {}
    for task in ('natural','lane','override'):
        rows=[s for s in scored if s['task']==task]
        times=[s['ms'] for s in rows if s['ms'] is not None]
        summary[task]={'outcomes':dict(Counter(s['grade'] for s in rows)),
                       'visible_latency_ms':{'n':len(times),'median':statistics.median(times),'range':[min(times),max(times)]} if times else None}
        if task=='natural':
            summary[task]['requested_vehicle_among_eligible'] = dict(Counter(s['measured_body'] for s in rows if s['eligible']))
            summary[task]['requested_vehicle_on_all'] = dict(Counter(s['measured_body'] for s in rows))
            summary[task]['correct_ground_and_unique_correct_vehicle'] = sum(
                s['grade'] in ('correct_direct','correct_choices_only') and s['measured_body']=='unique_correct' for s in rows)
            summary[task]['positive_first_requests'] = sum(s['eligible'] for s in rows)
            summary[task]['negative_first_requests'] = sum(not s['eligible'] for s in rows)
        if task=='override':
            summary[task]['superseded_proposals_refused'] = sum(400<=s.get('stale_offer_http_status',0)<500 for s in rows)
    return {'cohort':cohort,'original_reference_sha256':sha256(original).hexdigest(),'raw_browser_output_sha256':sha256(path.read_bytes()).hexdigest(),
            'summary':summary,'rows':scored}


if __name__=='__main__':
    commit=sys.argv[1]
    results=[grades(c,base/f'final-old14-{commit[:8]}-{c}'/'observations.json',commit) for c in ('primary','reserve')]
    if len(sys.argv)>2 and sys.argv[2]=='--replay':
        print(json.dumps(results,indent=2));sys.exit(0)
    evidence=base.parents[1]/'experiments/dropoff/passenger-rear-old14-final-browser-evidence-20261124.zip'
    with ZipFile(evidence, 'w', ZIP_DEFLATED, compresslevel=9) as archive:
        for cohort in ('primary','reserve'):
            first=base/f'final-old14-{commit[:8]}-{cohort}'/'observations.json'
            archive.write(first, first.relative_to(base))
            for section in ('reference','seal','requests','taps'):
                source=base/'field'/f'{cohort}-{section}.json'
                archive.write(source,source.relative_to(base))
        for method in (base/'field/grade_browser.py', base/'field-final-browser.cjs', Path(__file__)):
            archive.write(method,method.relative_to(base))
    all_rows=[r for arm in results for r in arm['rows']]
    firsts=[r for r in all_rows if r['task']=='natural']
    lanes=[r for r in all_rows if r['task']=='lane']
    overrides=[r for r in all_rows if r['task']=='override' and r['ms'] is not None]
    def latency(rows):
        measured=[r['ms'] for r in rows if r['ms'] is not None]
        return {'n':len(measured),'median':statistics.median(measured),'min':min(measured),'max':max(measured)}
    report={'release':commit,'port':8775,'scope':'Post-disclosure development replay on the original eight primary and six reserve sources. Both sets and all reference points were already known during development. The original untouched scores were retained in passenger-rear-field-browser-results-20261124.json.',
            'procedure':'Fresh normal Edge session on the verified original photo for each first natural request, each marked road control, and each attempted override. Only the first visually returned alternative was selected. Direct or selected locations required a separate Save and the identical original-pixel point afterwards. A superseded proposal token was retried separately. Explicit reference-only clarification earns no destination credit.',
            'reference':'Independent AI original-pixel reference annotated before the original study. Strict point-in-polygon grades do not establish dimensions, legal permission or physical stopping safety.',
            'original_study':{'initial_eight_at_82bfb03':'0/4 eligible received a correct point, 4/4 blocked withheld, 8/8 road taps withheld.',
                              'first_six_previously_unseen_at_287db6f':'0/3 eligible received a correct point, 3/3 blocked withheld, 6/6 road taps withheld.'},
            'combined_post_disclosure':{'natural':dict(Counter(r['grade'] for r in firsts)),
                'required_vehicle_on_seven_eligible':dict(Counter(r['measured_body'] for r in firsts if r['eligible'])),
                'required_vehicle_on_all_fourteen':dict(Counter(r['measured_body'] for r in firsts)),
                'current_vehicle_and_ground_correct_and_saved':sum(r['measured_body']=='unique_correct' and r['grade']=='correct_direct' and r['first_choice_save_verified'] for r in firsts),
                'separate_lane_marks':dict(Counter(r['grade'] for r in lanes)),
                'later_lane_overrides_after_a_real_offer':dict(Counter(r['grade'] for r in overrides)),
                'all_four_earlier_save_tokens_http_status':[r['stale_offer_http_status'] for r in overrides],
                'first_turn_latency_ms_including_clarifications':latency(firsts),'lane_latency_ms':latency(lanes),
                'override_latency_ms':latency(overrides),'browser_page_errors':sum(len(r['page_errors']) for r in all_rows)},
            'remaining_examples':{
                'U02':'The car outline matched the requested dark pickup by the bins, but the app withheld the destination.',
                'V02':'The first turn could not identify the stated dark blue sedan by the wall.',
                'V04':'The first turn could not identify the stated grey sedan farther up the right-hand side.',
                'V05':'A negative case withheld ground, yet the car outlined during clarification failed to overlap the requested car.'
            },
            'browser_evidence':evidence.name, 'browser_evidence_sha256':sha256(evidence.read_bytes()).hexdigest(),
            'reproduce_scoring':f'Extract the evidence archive, then run python field-final-grade.py {commit} --replay. This scores the saved ordinary browser observations and the originally locked reference polygons without access to model services.',
            'cohorts':results}
    destination=base.parents[1]/'experiments/dropoff/passenger-rear-old14-final-browser-20261124.json'
    destination.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    for s in results: print(s['cohort'],json.dumps(s['summary']))
