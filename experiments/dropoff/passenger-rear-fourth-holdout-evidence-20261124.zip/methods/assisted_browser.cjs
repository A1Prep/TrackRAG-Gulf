// Runs only on a completed, already scored study. The original 12 first-turn measurements remain unchanged.
const fs=require('node:fs'), path=require('node:path'), assert=require('node:assert/strict');
const {createHash}=require('node:crypto');
const {chromium}=require('playwright');
const base='http://127.0.0.1:8775';
const run=path.resolve('runs/passenger-rear-20261124');
const old=fs.readFileSync(path.join(run,'browser-fourth-first-pass','observations.json'));
assert.equal(createHash('sha256').update(old).digest('hex'),'a737131be29c6d850912bfe3469d95ba553780f84470877ca878bc450ba83056');
assert(JSON.parse(old).finished_utc);
const read=fn=>JSON.parse(fs.readFileSync(fn));
const filter=new Set(process.argv.slice(2));
const cases=read(path.join(__dirname,'fourth-reference.json')).cases.filter(c=>!filter.size||filter.has(c.id));
const out=path.join(run,filter.size?'browser-fourth-assisted-chosen':'browser-fourth-assisted');fs.mkdirSync(out,{recursive:true});
const progress=[];
const stateOf=v=>({state:v.state,boxes:v.result?.anchor_boxes_xyxy??[],point:v.result?.destination_point_xy??null,
    choices:v.bay_choices||[],actor:v.selected_by,can_request_area:v.can_request_area,reference_kind:v.reference_kind,
    message:v.result?.clarification_question??null,provider_error:v.error??null});
(async()=>{
 const catalog=(await(await fetch(base+'/api/scenes')).json()).scenes;
 const browser=await chromium.launch({executablePath:process.env.PASSENGER_CHROMIUM,headless:true,args:['--disable-gpu']});
 try{for(const target of cases){
  const scene=catalog.find(s=>s.recording_id===target.recording_id&&s.frame_id===target.frame_id);
  const tap=target.interior_xy??target.blocked_mark_xy;
  const r={id:target.id,sha256:target.sha256,request:target.words,intended_tap:tap,open_expected:target.eligible,browser_errors:[]};
  const page=await browser.newPage({viewport:{width:1290,height:865}});page.setDefaultTimeout(20000);
  try{
   page.on('pageerror',e=>r.browser_errors.push(e.message));
   await page.route('**/*',el=>new URL(el.request().url()).hostname==='127.0.0.1'?el.continue():el.abort());
   const [opened]=await Promise.all([page.waitForResponse(d=>new URL(d.url()).pathname==='/api/sessions'&&d.request().method()==='POST'),page.goto(base+'/?scene='+scene.key)]);
   const id=(await opened.json()).session;const view=async()=> (await(await page.request.get(base+'/api/sessions/'+id)).json()).view;
   await page.waitForFunction(()=>document.querySelector('#frame').naturalWidth>0&&!document.querySelector('#scene').disabled);
   const pixels=await page.request.get(new URL(await page.locator('#frame').getAttribute('src'),base).href);
   assert.equal(createHash('sha256').update(await pixels.body()).digest('hex'),target.sha256);
   await page.locator('#instruction').fill(target.words);await page.locator('#submit').click();
   await page.waitForFunction(()=>['proposed','clarify','error'].includes(document.querySelector('#destination-panel').dataset.state));
   r.first=stateOf(await view());assert.equal(r.first.state,'needs_clarification');
   r.mark_button=await page.locator('#draw').isVisible();assert(r.mark_button);
   await page.locator('#draw').click();const canvas=page.locator('#overlay');await canvas.scrollIntoViewIfNeeded();
   const rect=await canvas.boundingBox();await canvas.click({position:{x:tap[0]*rect.width/scene.width,y:tap[1]*rect.height/scene.height}});
   const t=performance.now();const [checked]=await Promise.all([page.waitForResponse(d=>d.url().endsWith('/area')),page.locator('#use-box').click()]);
   assert(checked.ok());const box=checked.request().postDataJSON().box;r.actual_tap=[(box[0]+box[2])/2,(box[1]+box[3])/2];
   assert(Math.hypot(r.actual_tap[0]-tap[0],r.actual_tap[1]-tap[1])<.004*Math.hypot(scene.width,scene.height));
   const v=(await checked.json()).view;
   await page.waitForFunction(s=>document.querySelector('#destination-panel').dataset.state===({needs_clarification:'clarify',proposed:'proposed',insufficient_visual_evidence:'clarify',error:'error'}[s]),v.state);
   r.visible_ms=Math.round(performance.now()-t);r.mark=stateOf(await view());r.title=await page.locator('#destination-title').innerText();r.user_visible=await page.locator('#status').innerText();
   r.save_visible=await page.locator('#confirm').isVisible();r.screenshot=target.id+'-marked.png';
   await page.screenshot({path:path.join(out,r.screenshot),fullPage:true});
   let proposed=r.mark;
   if(filter.size&&r.mark.choices.length&&target.eligible){
    assert(!r.save_visible&&!r.mark.point && r.mark.choices.length===1);
    const offer=r.mark.choices[0];
    const [choice]=await Promise.all([page.waitForResponse(d=>d.url().endsWith('/select-bay')),page.locator('[data-bay-id="'+offer.id+'"]').click()]);
    assert(choice.ok());await page.waitForFunction(()=>document.querySelector('#destination-panel').dataset.state==='proposed');
    proposed=stateOf(await view());assert.deepEqual(proposed.point,offer.center_xy);r.chosen=proposed;
    r.choice_message=await page.locator('#status').innerText();r.chosen_save_visible=await page.locator('#confirm').isVisible();assert(r.chosen_save_visible);
    await page.screenshot({path:path.join(out,target.id+'-chosen.png'),fullPage:true});
   }
   if(proposed.point&&(r.save_visible||r.chosen_save_visible)&&target.eligible){
    await page.locator('#confirm').click();await page.waitForFunction(()=>document.querySelector('#destination-panel').dataset.state==='confirmed');
    const confirmed=await view();assert.deepEqual(confirmed.result.destination_point_xy,proposed.point);r.same_point_explicitly_saved=true;
    await page.screenshot({path:path.join(out,target.id+'-saved.png'),fullPage:true});
   }
  }catch(e){r.error=String(e.stack||e)}finally{await page.close()}
  progress.push(r);fs.writeFileSync(path.join(out,'observed.json'),JSON.stringify({rows:progress},null,2));console.log(r.id,r.mark?.state,r.mark?.point,r.mark?.choices.length,r.user_visible,r.error||'');
 }}finally{await browser.close()}
 fs.writeFileSync(path.join(out,'observed.json'),JSON.stringify({finished_utc:new Date().toISOString(),rows:progress},null,2));
 assert(progress.every(r=>!r.error&&!r.browser_errors.length));
})().catch(e=>{console.error(e);process.exitCode=1});
