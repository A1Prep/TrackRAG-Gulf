"""Grade completed paired browser observations without letting gold enter browser or source preparation."""

import argparse
import hashlib
import json
import math
import pathlib
import re
import sys
import zipfile
from collections import Counter
from datetime import datetime, timezone

HERE = pathlib.Path(__file__).resolve().parent
sys.path.append(str(HERE.parent))
from grade_browser import body_measure, polygon_distance, stats

FROZEN_DECISION_COMMIT = "7187f6e715ab88183d29d2936bb71c0a9a710c2e"

NAMES = {
    "requests": "third-requests.json",
    "road_taps": "third-taps.json",
    "reference": "third-reference.json",
    "sources": "third-sources.json",
}
PUBLIC_SOURCE_FIELDS = (
    "id", "photo_id", "recording_id", "frame_id", "captured", "size", "sha256", "lat", "lng",
    "source_url", "license", "license_url", "source_terms", "attribution", "original_blur_status",
)
ARCHIVE_SECTIONS = {
    "requests": "blind_inputs",
    "road_taps": "blind_inputs",
    "reference": "independent_reference",
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def utc(stamp):
    value = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
    assert value.tzinfo
    return value.astimezone(timezone.utc)


def grade_row(row, target):
    assert target["sha256"] == row["sha256"]
    result = row.get("result") or {}
    point = result.get("destination_point_xy")
    choices = row.get("choices") or []
    anchor = body_measure(result.get("anchor_boxes_xyxy") or [], target["anchor_boxes_xyxy"])
    failed = row.get("terminal") != "completed" or bool(row.get("error")) or row.get("state") == "error"
    direct = bool(point and row.get("proposal") and row.get("save_visible") and row.get("state") == "proposed")

    def margin(xy):
        return max((polygon_distance(xy, polygon) for polygon in target["ground_polygons_xy"]), default=None)

    distance = margin(point) if point else None
    alternatives = []
    for choice in choices:
        center = choice["center_xy"]
        assert len(center) == 2 and len(choice["polygon_xy"]) >= 3 and choice["id"]
        assert not direct and row["state"] == "needs_clarification" and not row["save_visible"]
        delta = margin(center)
        alternatives.append({
            "id": choice["id"], "center": center, "strictly_inside": delta is not None and delta > 0,
            "signed_margin_px": round(delta, 2) if delta is not None else None, "extent": choice.get("extent"),
        })
    if row["task"] == "lane" and not failed:
        assert math.dist(row["actual_tap"], target["lane_xy"]) <= 0.004 * math.hypot(*target["size"])
    if failed:
        outcome = "operational_failure"
    elif row["task"] == "lane":
        if direct:
            nearby = math.dist(point, row["actual_tap"]) < 0.025 * math.hypot(*target["size"])
            outcome = "road_tap_approved" if nearby else "road_tap_relocated"
        else:
            assert row.get("state") in ("needs_clarification", "insufficient_visual_evidence")
            assert not point and not row.get("proposal") and not row.get("save_visible")
            outcome = "road_tap_alternatives" if choices else "road_tap_withheld"
    elif direct:
        if distance is not None and distance > 0:
            outcome = "direct_correct"
        else:
            outcome = "wrong_region" if target["eligible"] else "false_offer"
        assert row["save_verified"]
    elif choices:
        if any(alternative["strictly_inside"] for alternative in alternatives):
            outcome = "alternative_available"
        else:
            outcome = "wrong_alternatives" if target["eligible"] else "false_alternatives"
    else:
        assert row.get("state") in ("needs_clarification", "insufficient_visual_evidence")
        assert not point and not row.get("proposal") and not row.get("save_visible")
        outcome = "clear_withheld" if target["eligible"] else "negative_withheld"
    return {
        "id": row["id"], "task": row["task"], "eligible": target["eligible"], "outcome": outcome, "anchor": anchor,
        "point": point, "signed_ground_margin_px": round(distance, 2) if distance is not None else None,
        "alternatives": alternatives, "explicit_save": bool(row.get("save_verified")), "visible_ms": row.get("visible_ms"),
        "actual_tap": row.get("actual_tap"), "error": row.get("error") or row.get("problem"),
        "browser_errors": row.get("browser_errors") or [],
    }


def compile_grade(observations, release, field_read, public_sources, require_source_digest):
    browser = json.loads(observations)
    assert browser.get("finished_utc") and re.fullmatch("[a-f0-9]{40}", release) and browser["candidate"] == release
    assert len(browser["rows"]) == 16
    unique = {(row["id"], row["task"]) for row in browser["rows"]}
    assert len(unique) == 16
    seal = json.loads(field_read("seal"))
    assert utc(seal["frozen_utc"]) < utc(browser["finished_utc"])
    names = NAMES.keys() if require_source_digest else ARCHIVE_SECTIONS.keys()
    for name in names:
        assert sha(field_read(name)) == seal["sha256"][name]
    assert browser["requests_sha256"] == seal["sha256"]["requests"] and browser["taps_sha256"] == seal["sha256"]["road_taps"]
    gold = {g["id"]: g for g in json.loads(field_read("reference"))["cases"]}
    assert unique == {(cid, task) for cid in gold for task in ("natural", "lane")}
    assert {r["id"] for r in public_sources} == set(gold)
    for source in public_sources:
        assert all(source[key] == gold[source["id"]][key] for key in ("sha256", "size", "recording_id", "frame_id"))
    samples = [grade_row(row, gold[row["id"]]) for row in browser["rows"]]
    summary = {}
    for task in ("natural", "lane"):
        rows = [row for row in samples if row["task"] == task]
        summary[task] = {
            "eligible": sum(r["eligible"] for r in rows),
            "ineligible": sum(not r["eligible"] for r in rows),
            "outcomes": dict(Counter(r["outcome"] for r in rows)),
            "visible_ms": stats([r["visible_ms"] for r in rows if r["visible_ms"] is not None]),
            "outlines": dict(Counter(r["anchor"]["classification"] for r in rows)),
            "eligible_outlines": dict(Counter(r["anchor"]["classification"] for r in rows if r["eligible"])),
            "correct_pin_and_unique_vehicle": sum(r["outcome"] == "direct_correct" and r["anchor"]["classification"] == "unique_correct" for r in rows),
            "correct_pin_and_visible_vehicle": sum(r["outcome"] == "direct_correct" and r["anchor"]["classification"] in ("unique_correct", "correct_among_several") for r in rows),
            "total_selectable_alternatives": sum(len(r["alternatives"]) for r in rows),
            "correct_alternative_with_wrong_choices_also_shown": sum(
                r["outcome"] == "alternative_available" and any(not x["strictly_inside"] for x in r["alternatives"]) for r in rows
            ),
            "console_error_events": sum(len(r["browser_errors"]) for r in rows),
            "explicit_saves": sum(r["explicit_save"] for r in rows),
        }
    return {
        "commit": release, "frozen_decision_commit": FROZEN_DECISION_COMMIT,
        "reference_sealed_utc": seal["frozen_utc"], "browser_finished_utc": browser["finished_utc"],
        "original_browser_observations_sha256": sha(observations), "independent_seal": seal,
        "reviewer": "Independent AI visual review of original UAE driver-view photos before model predictions. No human label collection.",
        "scope": "Eight photographs from eight new drives selected before testing. Capture days are distinct and drives do not overlap the earlier fourteen. A small hand-selected sample cannot establish fleet performance.",
        "measurement": {
            "direct": "A destination must be strictly inside a preregistered native-pixel polygon and remain at the same place after an explicit save. Correct vehicle and ground jointly are also reported. All crop or body evidence alone is scored separately.",
            "body": "Intersection over union >=0.50 identifies a source vehicle. A unique correct outline, the intended vehicle shown among alternatives, a wrong-only outline and no outline are separate.",
            "choice": "A selectable alternative is scored by its displayed center independently. It earns no direct hit and the correct alternative may be offered alongside erroneous choices.",
            "road": "Each original prelabelled road tap comes from a fresh session. One road probe is the vehicle through aisle of a gravel parking lot. A relocated pin or list returned for the road tap is reported separately from a clean refusal.",
            "time": "Browser-visible wall time after pressing Submit, in milliseconds. Photo loading, offline source preparation and a human pressing Save are excluded.",
        },
        "summary": summary, "rows": samples,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--observations", type=pathlib.Path)
    parser.add_argument("--release")
    parser.add_argument("--out", type=pathlib.Path)
    parser.add_argument("--archive", type=pathlib.Path)
    parser.add_argument("--replay", type=pathlib.Path)
    args = parser.parse_args()
    if args.replay:
        with zipfile.ZipFile(args.replay) as archive:
            observation = archive.read("browser_outputs/observations.json")
            sources = json.loads(archive.read("public_sources.json"))
            def field_read(name):
                if name == "seal":
                    return archive.read("independent_reference/third-seal.json")
                return archive.read(ARCHIVE_SECTIONS[name] + "/" + NAMES[name])
            report = compile_grade(observation, json.loads(observation)["candidate"], field_read, sources, False)
        print(json.dumps(report, indent=2))
        return
    if not (args.observations and args.release and args.out):
        parser.error("--observations, --release and --out are required for a completed browser study")
    observation = args.observations.read_bytes()
    def field_read(name):
        filename = "third-seal.json" if name == "seal" else NAMES[name]
        return (HERE / filename).read_bytes()
    sources = [{key: row[key] for key in PUBLIC_SOURCE_FIELDS} for row in json.loads(field_read("sources"))["sources"]]
    report = compile_grade(observation, args.release, field_read, sources, True)
    if args.archive:
        args.archive.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(args.archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            archive.writestr("browser_outputs/observations.json", observation)
            archive.writestr("public_sources.json", json.dumps(sources, indent=2, ensure_ascii=False))
            archive.writestr("independent_reference/third-seal.json", field_read("seal"))
            for name, section in ARCHIVE_SECTIONS.items():
                archive.writestr(section + "/" + NAMES[name], field_read(name))
            archive.write(HERE.parents[1] / "field-browser.cjs", "methods/field-browser.cjs")
            archive.write(HERE.parent / "grade_browser.py", "methods/grade_browser.py")
            archive.write(pathlib.Path(__file__), "methods/grade_live.py")
        report.update({
            "evidence_archive": args.archive.name, "evidence_archive_sha256": sha(args.archive.read_bytes()),
            "reproduce": "Extract methods/grade_live.py and methods/grade_browser.py together, then run python grade_live.py --replay <archive.zip>. The Python standard library can reproduce the case and group scores from frozen browser outputs and references.",
        })
    args.out.parent.mkdir(exist_ok=True, parents=True)
    args.out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf8")
    print(json.dumps(report["summary"]))


if __name__ == "__main__":
    main()
