const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {createHash} = require('node:crypto');
const {chromium} = require('playwright');
const folder = path.resolve('runs/passenger-rear-20261124');
const field = path.join(folder,'field','third');
const sources = JSON.parse(fs.readFileSync(path.join(field,'third-requests.json'))).requests;
const taps = JSON.parse(fs.readFileSync(path.join(field,'third-taps.json')));
const base = 'http://127.0.0.1:'+process.argv[2];
const out = path.join(folder,'development','rear-canonical-evidence-'+process.argv[2]);
fs.mkdirSync(out,{recursive:true});
async function run() {
  const catalog = (await (await fetch(base+'/api/scenes')).json()).scenes;
  const browser=await chromium.launch({executablePath:process.env.PASSENGER_CHROMIUM,headless:true,args:['--disable-gpu']});
  const records=[];
  try {
    for (const [id,kind] of [['Wb7e43b4','conditional-shop'],['W36b2dc6','direct-profile'],['W5cc54a2','shade'],['Wb7e43b4','road'],['W36b2dc6','road']]) {
      const item=sources.find(x=>x.id===id);
      const frame=catalog.find(x=>x.recording_id===item.recording_id && x.frame_id===item.frame_id);
      assert(frame, 'missing source '+id);
      const page=await browser.newPage({viewport:{width:1290,height:855}});
      page.setDefaultTimeout(20000);
      const errors=[];
      page.on('pageerror',e=>errors.push(e.message));
      await page.route('**/*',route=>new URL(route.request().url()).hostname==='127.0.0.1' ? route.continue():route.abort());
      try {
        const [start]=await Promise.all([page.waitForResponse(r=>new URL(r.url()).pathname==='/api/sessions' && r.request().method()==='POST'),page.goto(base+'/?scene='+frame.key,{waitUntil:'domcontentloaded'})]);
        const session=(await start.json()).session;
        const read=async()=> (await(await page.request.get(base+'/api/sessions/'+session)).json()).view;
        const visible=async(expected)=>{
          await page.waitForFunction(target=>target.includes(document.querySelector('#destination-panel').dataset.state),expected,{timeout:47000});
          return {state:await read(),save:await page.locator('#confirm').isVisible(),message:await page.locator('#status').innerText(),title:await page.locator('#destination-title').innerText()};
        };
        const snapshot=async(stage)=>await page.screenshot({path:path.join(out,id+'-'+kind+'-'+stage+'.png'),fullPage:true});
        await page.waitForFunction(()=>document.querySelector('#frame').naturalWidth>0 && !document.querySelector('#scene').disabled);
        const photo=await page.request.get(new URL(await page.locator('#frame').getAttribute('src'),base).href);
        assert.equal(createHash('sha256').update(await photo.body()).digest('hex'),item.sha256);
        await page.locator('#instruction').fill(item.words);
        const t=Date.now();
        if(kind==='road'){
          await page.locator('#submit-area').click();
          await page.locator('#draw-tools').waitFor();
          const canvas=page.locator('#overlay');
          await canvas.scrollIntoViewIfNeeded();
          const rect=await canvas.boundingBox(), p=taps.find(x=>x.id===id).lane_xy;
          await canvas.click({position:{x:p[0]/frame.width*rect.width, y:p[1]/frame.height*rect.height}});
          const [response]=await Promise.all([page.waitForResponse(r=>r.url().endsWith('/area')),page.locator('#use-box').click()]);
          const q=response.request().postDataJSON().box; const real=[(q[0]+q[2])/2,(q[1]+q[3])/2];
          assert(Math.hypot(real[0]-p[0],real[1]-p[1])<.004*Math.hypot(frame.width,frame.height));
          const withheld=await visible(['clarify']);
          assert(!withheld.save && !withheld.state.proposal_id && !withheld.state.result.destination_point_xy && !withheld.state.bay_choices?.length);
          await snapshot('withheld');
          records.push({id,kind,session,source:item.sha256,real_tap:real,ms:Date.now()-t,readback:withheld,errors});
          continue;
        }
        const confirmations=[];
        page.on('request',r=>{if(r.method()==='POST' && r.url().endsWith('/confirm'))confirmations.push(r.postDataJSON())});
        await page.locator('#submit').click();
        const first=await visible(['proposed','clarify','error']); const ms=Date.now()-t;
        await snapshot('first');
        assert.equal(confirmations.length,0);
        const rec={id,kind,session,source:item.sha256,ms,first,errors};
        if(kind==='conditional-shop'){
          assert.equal(first.state.state,'needs_clarification');assert(!first.save && !first.state.proposal_id && !first.state.result.destination_point_xy);
          assert.equal(first.state.bay_choices.length,1);assert(/furniture shop/i.test(first.message));assert(/couldn.t verify|unverified|could not verify/i.test(first.message));
          const original=first.state.bay_choices[0];
          const choice=page.locator('#bay-buttons button');await choice.click();
          rec.chosen=await visible(['proposed']);assert(rec.chosen.save);
          assert.equal(rec.chosen.state.selected_by,'passenger');
          assert.equal(rec.chosen.state.unverified_place_name,'furniture shop');
          assert.deepEqual(rec.chosen.state.result.destination_point_xy,original.center_xy);
          assert.deepEqual(rec.chosen.state.result.anchor_boxes_xyxy,first.state.result.anchor_boxes_xyxy);
          assert(/furniture shop/i.test(rec.chosen.message) && /unverified|couldn.t verify/i.test(rec.chosen.message));
          await snapshot('chosen');
        }else if(kind==='direct-profile'){
          assert.equal(first.state.state,'proposed');assert(first.save && first.state.proposal_id && first.state.result.destination_point_xy);
          assert(first.state.result.anchor_boxes_xyxy.length===1);
        }else{
          assert(!first.save && !first.state.proposal_id && !first.state.result.destination_point_xy);
          assert(first.state.result.anchor_boxes_xyxy.length===1);
          assert(/light|paint|beige/i.test(first.message));
          records.push(rec);continue;
        }
        assert.equal(confirmations.length,0);
        const offered=rec.chosen || first;
        await page.locator('#confirm').click();
        const saved=await visible(['confirmed']);
        assert.equal(confirmations.length,1);assert.deepEqual(saved.state.result.destination_point_xy,offered.state.result.destination_point_xy);
        assert.equal(saved.state.selected_by,offered.state.selected_by);assert(!saved.save);
        rec.saved=saved;rec.confirm_clicks=confirmations.length;
        await snapshot('saved');records.push(rec);
      }catch(e){
        await page.screenshot({path:path.join(out,id+'-'+kind+'-failure.png'),fullPage:true}).catch(()=>{});
        records.push({id,kind,error:String(e.stack||e),errors});
      }finally{await page.close();}
      fs.writeFileSync(path.join(out,'results.json'),JSON.stringify(records,null,2));
    }
  }finally{await browser.close();}
  fs.writeFileSync(path.join(out,'results.json'),JSON.stringify(records,null,2));
  for (const r of records) console.log(r.id,r.kind,r.error||r.first?.state?.state||r.readback?.state?.state,r.saved?.state?.state||'',r.ms||0,r.first?.message||r.readback?.message||'');
  assert(records.every(r=>!r.error && !r.errors.length));
}
run().catch(e=>{console.error(e);process.exitCode=1});
