"""Source-image/scaled-map counterfactuals only on the opened third red car, no further field data."""
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import json
import numpy as np
from PIL import Image, ImageDraw
from trackrag.passenger_app import load_scenes
from trackrag.dropoff import local_surfaces,local_vehicle_observations,manual_surfaces,vehicle_rear_marked_strip as marked

base=Path('runs/passenger-rear-20261124/third-b-prepared')
digest=lambda p:sha256(p.read_bytes().replace(b'\r\n',b'\n')).hexdigest()
sf=base/'surfaces/passenger-local-image-surfaces-v1.json'; ob=base/'vehicle-views-v2/vehicle-observations.json'
local_surfaces.register(sf,digest(sf));local_vehicle_observations.register(ob,digest(ob))
scene=next(s for s in load_scenes([Path('data/uae-parking-local-rear-transfer-b-20261124/passenger-requests.jsonl')]).values() if s['provenance']['image_sha256'].startswith('b7e43b4'))
key=scene['provenance']['image_sha256'];frame=scene['frame'];path=Path(frame['image_path']);photo=Image.open(path).convert('RGB')
classes=manual_surfaces.decode(local_surfaces.get_packet(key),frame,key)
packet=local_vehicle_observations.get_packet(key);specs=local_vehicle_observations.specs_for(packet,scene,classes)
answers=local_vehicle_observations.verify(scene,path.read_bytes(),specs,packet)
spec=next(s for s,ans in zip(specs,answers) if ans[0]=='red' and ans[2]=='REAR')
def one(im,labels,sc=scene):
    found=marked.candidates(im,labels,sc,spec,facing='REAR')
    return [(x['point'],x['evidence']['measured_rows']) for x in found]
h,w=classes.shape;scale=np.array([w/photo.width,h/photo.height]);x0,y0,x1,bottom=np.int32(np.array(spec['box'])*np.tile(scale,2))
x,y=np.rint(np.array(spec['ground']['point'])*scale).astype(int)
print('map,vehicle,point',classes.shape,(x0,y0,x1,bottom),(x,y),'baseline',one(photo,classes),flush=True)
c=classes.copy()
def image_change(labels,pixels,second):
    im=photo.copy()
    mask=Image.fromarray(np.uint8(pixels)*255).resize(photo.size,Image.Resampling.NEAREST)
    im.paste((190,185,172),mask=mask)
    dark=Image.fromarray(np.uint8(second)*255).resize(photo.size,Image.Resampling.NEAREST)
    im.paste((68,66,60),mask=dark)
    return one(im,labels)
for high in (2,3,5,7,9):
    labels=classes.copy();pix=np.zeros_like(classes,bool)
    for yy in range(bottom+2,bottom+2+high):
        # Transverse concrete barrier from the actual traffic boundary to the signed side kerb.
        start=next(i for i in range(390,492) if classes[yy,i]==10)
        stop=next((i for i in range(start+1,515) if classes[yy,i] not in (10,24)),515)
        pix[yy,start:stop]=True
    labels[pix]=5
    second=pix.copy();second[:bottom+3]=False
    print('transverse signed barrier',high,image_change(labels,pix,second))
for high in (0,4,7,10,18,35):
    labels=classes.copy(); pix=np.zeros_like(classes,bool); shade=np.zeros_like(classes,bool)
    for yy in range(395,h):
        if bottom+5 <= yy < bottom+5+high:continue
        r=classes[yy]; choices=np.flatnonzero((r[:-1]==13)&np.isin(r[1:],(10,24)))+1
        if not len(choices):continue
        predict=416+1.44*(yy-445)
        edge=choices[np.argmin(np.abs(choices-predict))]
        if abs(edge-predict)>48:continue
        pix[yy,edge-3:edge+3]=True; shade[yy,edge-3:edge-1]=True
    labels[pix]=5;print('fence lateral aperture',high,image_change(labels,pix,shade))
