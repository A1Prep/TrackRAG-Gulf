"""Keep the separately assisted test outside all initial holdout metrics."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZipFile, ZIP_DEFLATED

HERE = Path(__file__).resolve().parent
sys.path.append(str(HERE.parent))
from grade_browser import polygon_distance


def digest(data):
    return sha256(data).hexdigest()


def supplement(firsts, gold, assisted, confirmed, native):
    assert firsts["finished_utc"] and assisted["finished_utc"] > firsts["finished_utc"]
    assert confirmed["finished_utc"] > firsts["finished_utc"]
    primary = {r["id"]:r for r in firsts["rows"] if r["task"]=="natural"}
    desired = {r["id"]:r for r in gold["cases"]}
    checks = {r["id"]:r for r in native}
    saved = {r["id"]:r for r in confirmed["rows"]}
    assert sorted(primary)==sorted(desired)==sorted(checks)==sorted(r["id"] for r in assisted["rows"])
    outcomes = []
    for r in assisted["rows"]:
        case, original, matter = desired[r["id"]], primary[r["id"]], checks[r["id"]]
        assert r["sha256"] == case["sha256"] and r["open_expected"]==case["eligible"]
        assert r["intended_tap"] == (case["interior_xy"] or case["blocked_mark_xy"])
        assert not r.get("error") and not r["browser_errors"]
        assert r["mark_button"] and not r["save_visible"] and not r["mark"]["point"]
        options = r["mark"]["choices"]
        after = saved.get(r["id"])
        outcome = "continued_withhold"
        if options:
            assert len(options)==1 and after and after.get("same_point_explicitly_saved")
            assert after["chosen_save_visible"] and after["chosen"]["actor"]=="passenger"
            assert after["chosen"]["point"] == options[0]["center_xy"] == r["actual_tap"]
            outcome = "correct_passenger_chosen_point" if any(polygon_distance(after["chosen"]["point"],p)>0 for p in case["ground_polygons_xy"]) else "wrong_passenger_choice"
        options_seen = [] if not options else [{
            "point":q["center_xy"],
            "distance_inside_frozen_region_px":round(max(polygon_distance(q["center_xy"],poly) for poly in case["ground_polygons_xy"]),2),
            "extent":q["extent"],
        } for q in options]
        outcomes.append({
            "id":r["id"], "drive":case["recording_id"], "frame":case["frame_id"],"eligible":case["eligible"],
            "passenger_words":r["request"], "source_sha256":r["sha256"], "original_reply":original["message"],
            "independently_visible_rear":case["rear_direction"], "independently_visible_ground":case["evidence"],
            "assisted_tap_xy":r["actual_tap"], "ground_class_at_tap":matter["center_class"],
            "tap_region_parking_cells":matter["checked"].get("mark_parking_cells"),
            "tap_region_total_cells":matter["checked"].get("mark_cells"),
            "neighborhood_parking_cells":matter["checked"].get("nearby_parking_cells"),
            "neighborhood_total_cells":matter["checked"].get("nearby_cells"),
            "intersecting_vehicle_ids":matter["checked"]["intersecting_current_track_ids"],
            "assisted_reply":r["user_visible"], "assisted_ms":r["visible_ms"], "assisted_outcome":outcome,
            "assisted_choices":options_seen, "same_point_explicitly_saved":bool(after and after["same_point_explicitly_saved"]),
        })
    return {
        "design":"After the six first requests and six lane clicks were sealed and scored, repeat the original requests in ordinary Microsoft Edge and press the real mark button. Tap the preregistered ground inside each eligible site or the specifically obstructed spot for each control. Any conditional choice requires an explicit selection and then a separate Save. This is an assisted test after disclosure and cannot earn first-turn accuracy.",
        "completed":assisted["finished_utc"], "selection_completed":confirmed["finished_utc"],
        "eligible_outcomes":dict(Counter(r["assisted_outcome"] for r in outcomes if r["eligible"])),
        "negative_outcomes":dict(Counter(r["assisted_outcome"] for r in outcomes if not r["eligible"])),
        "native_read":"The released source-bound segmentation raster was reloaded independently. Counts cover the browser's actual tap rectangle and its 49-cell neighbourhood. The application's vehicle relation, collision and parking checks are additional conditions. A semantic class at one point cannot prove the whole bay or permission to stop.",
        "rows":outcomes,
    }


def main():
    if len(sys.argv)>1:
        with ZipFile(sys.argv[1]) as z:
            result=supplement(*[json.loads(z.read(k)) for k in (
                "browser_outputs/observations.json","independent_reference/fourth-reference.json",
                "assisted/observations.json","assisted/chosen.json","assisted/registered-surfaces.json")])
        print(json.dumps(result));return
    run=HERE.parents[1]
    exp=Path("experiments/dropoff")
    out=exp/"passenger-rear-fourth-holdout-20261124.json"
    archive=exp/"passenger-rear-fourth-holdout-evidence-20261124.zip"
    report=json.loads(out.read_bytes())
    first=run/"browser-fourth-first-pass/observations.json"; follow=run/"browser-fourth-assisted/observed.json"
    choice=run/"browser-fourth-assisted-chosen/observed.json"; native=run/"browser-fourth-assisted/native_surfaces.json"
    gold=HERE/"fourth-reference.json"
    assert digest(first.read_bytes())=="a737131be29c6d850912bfe3469d95ba553780f84470877ca878bc450ba83056"
    assert digest(gold.read_bytes())=="42b54ef6bfd0705035c101447532af587af715b5d0a0cdd95cf0ac0ce136d275"
    report["after_unsealing_assisted"]=supplement(*[json.loads(p.read_bytes()) for p in (first,gold,follow,choice,native)])
    report["source_enrollment_release"]="272a59cb03f802e003f3c651d083e658091dbc6c"
    report["initial_browser_run"]={"runner":"methods/field-browser.cjs","tasks":["natural","lane"],"enrollment_commit":"272a59cb03f802e003f3c651d083e658091dbc6c","frozen_decision_commit":"316f5c120c2d24f901323d30a198ee2665f986aa"}
    report["sampling"]=json.loads(gold.read_bytes())["sampling"]
    report["driver_acceptance_interpretation"]="All three eligible vehicles were individually and correctly outlined, so identity was successfully communicated in those requests. The initial system supplied zero eligible ground locations. An open apron, a parking row defined by white studs and a warehouse gravel frontage have distinct physical cues; combining a vehicle outline and a broad semantic class does not verify a load-bearing, vehicle-accessible area behind the vehicle. An application failure does not count as a correct refusal."
    report["assisted_journal"]={"sha256":"67de3fae1e6bd24da4b3ab7140db90dfc248e21e5113abd839032b3e56b518b1","timing":"After first-turn outcome grading","actions":["opened","submitted","passenger_marked","passenger_selected_bay","confirmed"],"chosen_reason":"choose_passenger_marked_parking_ground","bay_outline":None,"explicit_passenger_ground":True,"extent":"interior_point_only","approach":"A directly checked, unoccupied exact mark followed by a choice and Save; this did not confirm its physical relation to the pickup or the full extent of a bay."}
    report["local_gallery"]="runs/passenger-rear-20261124/browser-fourth-first-pass/independent-six-drive-gallery.jpg"
    report["local_assisted_screens"]="runs/passenger-rear-20261124/browser-fourth-assisted-chosen/"
    with ZipFile(archive,"a",ZIP_DEFLATED,compresslevel=9) as z:
        assert "assisted/observations.json" not in z.namelist()
        for p,name in ((follow,"assisted/observations.json"),(choice,"assisted/chosen.json"),(native,"assisted/registered-surfaces.json"),
                       (run/"field-final-browser.cjs","methods/field-final-browser.cjs"),
                       (HERE/"assisted_browser.cjs","methods/assisted_browser.cjs"),(Path(__file__),"methods/supplement_fourth.py")):z.write(p,name)
    report["evidence_archive_sha256"]=digest(archive.read_bytes())
    report["reproduce"]+=" For the separate assisted readback, place methods/supplement_fourth.py beside grade_browser.py, then run python supplement_fourth.py <archive.zip>."
    out.write_text(json.dumps(report,indent=2,ensure_ascii=False)+"\n",encoding="utf8")
    print(out,digest(out.read_bytes()),archive,digest(archive.read_bytes()))

if __name__=="__main__":
    main()
