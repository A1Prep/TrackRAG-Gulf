"""Summarise the opened third photo set from real browser responses. No driver screenshots in Git."""
import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZIP_DEFLATED, ZipFile

HERE = Path(__file__).resolve().parent
sys.path.append(str(HERE.parent / "field/third"))
from grade_live import grade_row, stats


def check(value):
    return sha256(value).hexdigest()


def compare(first, refined, gold):
    target = {r["id"]: r for r in gold["cases"]}
    summary, ratings = {}, {}
    for label, observed in (("original_unseen", first), ("after_repair_on_seen_photos", refined)):
        assert observed.get("finished_utc")
        rows = [r for r in observed["rows"] if r["task"] in {"natural", "lane"}]
        assert {(r["id"], r["task"]) for r in rows} == {(i, k) for i in target for k in ("natural", "lane")}
        assert len(rows) == 16
        ratings[label] = [grade_row(row, target[row["id"]]) for row in rows]
        summary[label] = {}
        for kind in ("natural", "lane"):
            items = [r for r in ratings[label] if r["task"] == kind]
            summary[label][kind] = dict(
                counts=dict(Counter(r["outcome"] for r in items)),
                visible_ms=stats([r["visible_ms"] for r in items]),
                visible_bodies=dict(Counter(r["anchor"]["classification"] for r in items)),
                alternatives=sum(len(r["alternatives"]) for r in items),
                explicitly_saved=sum(r["explicit_save"] for r in items),
                console_errors=sum(len(r["browser_errors"]) for r in items),
            )
    changes = {r["id"]: r for r in ratings["original_unseen"] if r["task"] == "natural"}
    for r in ratings["after_repair_on_seen_photos"]:
        if r["task"] == "natural":
            r["original_unseen_outcome"] = changes[r["id"]]["outcome"]
    overrides = [r for r in refined["rows"] if r["task"] == "override" and r["terminal"] == "completed"]
    assert len(overrides) == sum(r["explicit_save"] for r in ratings["after_repair_on_seen_photos"] if r["task"] == "natural")
    checks = []
    for r in overrides:
        assert r["previous_offer_rejected"] and r["stale_offer_status"] == 409
        assert not r["proposal"] and not r["save_visible"] and not r["choices"]
        assert r["result"]["destination_point_xy"] is None
        checks.append({"id": r["id"], "replaced_point": r["original_point"], "road_tap": r["actual_tap"], "obsolete_save_http": r["stale_offer_status"]})
    return {"summary": summary, "after_repair_rows": ratings["after_repair_on_seen_photos"], "replaced_proposals": checks}


def focus(records):
    output = []
    for r in records:
        assert not r["errors"] and not r.get("error")
        stages = {}
        for k in ("first", "chosen", "saved", "readback"):
            if k not in r:
                continue
            stage = r[k]
            state = stage["state"]
            stages[k] = {
                "display_message": stage["message"], "state": state["state"], "save_visible": stage["save"],
                "native_point": state["result"].get("destination_point_xy"),
                "body_boxes": state["result"].get("anchor_boxes_xyxy", []), "actor": state.get("selected_by"),
                "conditional_place": state.get("unverified_place_name"), "choices": state.get("bay_choices", []),
            }
        output.append({"id": r["id"], "scenario": r["kind"], "image_sha256": r["source"],
                       "elapsed_ms": r["ms"], "confirmation_posts": r.get("confirm_clicks", 0),
                       "tested_tap": r.get("real_tap"), "stages": stages})
    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", type=Path)
    parsed = parser.parse_args()
    if parsed.replay:
        with ZipFile(parsed.replay) as z:
            load = lambda n: json.loads(z.read(n))
            replay = compare(load("observed/original.json"), load("observed/post_repair.json"), load("independent_reference.json"))
        print(json.dumps(replay, indent=2))
        sys.exit(0)

    run = HERE.parent
    field = run / "field/third"
    root = Path.cwd()
    exp = root / "experiments/dropoff"
    archive = exp / "passenger-rear-third-development-replay-evidence-20261124.zip"
    output = exp / "passenger-rear-third-development-replay-20261124.json"
    first = run / "browser-third-first-pass/observations.json"
    new = run / "browser-third-open-fix-316f5c1/observations.json"
    reference = field / "third-reference.json"
    raw = {k: p.read_bytes() for k, p in (("first", first), ("new", new), ("gold", reference))}
    expected = json.loads((field / "third-seal.json").read_bytes())["sha256"]
    assert expected["reference"] == check(raw["gold"])
    first_reads, new_reads, ref = [json.loads(raw[k]) for k in ("first", "new", "gold")]
    assert new_reads["candidate"] == "316f5c120c2d24f901323d30a198ee2665f986aa"
    for observed in (first_reads, new_reads):
        assert observed["taps_sha256"] == expected["road_taps"] and observed["requests_sha256"] == expected["requests"]
    result = compare(first_reads, new_reads, ref)
    screens = HERE / "rear-canonical-evidence-8775"
    audited = focus(json.loads((screens / "results.json").read_bytes()))
    with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=9) as z:
        z.writestr("observed/original.json", raw["first"])
        z.writestr("observed/post_repair.json", raw["new"])
        z.writestr("observed/focused-browser.json", json.dumps(audited, ensure_ascii=False, indent=2))
        z.writestr("independent_reference.json", raw["gold"])
        z.write(run / "field-final-browser.cjs", "methods/field-final-browser.cjs")
        z.write(field / "grade_live.py", "methods/grade_live.py")
        z.write(field.parent / "grade_browser.py", "methods/grade_browser.py")
        for name in ("review_third_open.py", "independent-profile-ground.py", "independent-marked-ground.py", "independent-current-rear-browser.cjs"):
            z.write(HERE / name, "methods/" + name)
    receipt = {
        "purpose": "A post-repair check on eight previously opened UAE driving photos. The blind third test remains a distinct result. This check does not measure new-drive performance.",
        "release": new_reads["candidate"], "earlier_decision_release": first_reads["candidate"],
        "after_repair_browser_finished_utc": new_reads["finished_utc"], "original_raw_sha256": check(raw["first"]),
        "post_repair_raw_sha256": check(raw["new"]), "gold_sha256": expected["reference"],
        "earlier_evidence": "passenger-rear-third-holdout-20261124.json",
        "adjudication": "A separate AI reviewer viewed the original images, sealed vehicle boxes and permissible ground polygons before the original blind requests. There were no human judges.",
        "measurement": "Vehicle matches require native image box intersection-over-union of at least 0.50. A direct hit additionally requires the native point strictly inside a target polygon and an explicit save at that same place. One good choice earns a separate guided result. Eight fresh sessions tested originally labelled through roads. Two further live sessions replaced genuine offers and tried their old save tokens. Timings are browser-visible on this laptop with prepared source evidence.",
        **result,
        "separate_focused_browser_sessions": audited,
        "adverse_physical_controls": {
            "side_view_profile": {
                "scene": "600 by 400 source and map. The near vehicle is 140 by 65 pixels. The companion has a separate visible body and ground contact.",
                "before_repair_false_offers": ["A solid kerb passing under the row companion wheel contact", "A fence restricting a contiguous access opening to 17 map rows"],
                "after_held": ["Road class everywhere", "Occupied point", "Continuous kerb below companion", "Continuous kerb below both vehicles", "Closed kerb", "17-row pedestrian opening"],
                "after_offered": {"Clear adjacent parking": [343.5, 201.5], "75-row access opening": [343.5, 201.5]},
            },
            "measured_marked_row": {
                "scene": "In-memory interventions in the already opened red-car original and the aligned 900 by 506 raster. Paint and parked vehicle are unchanged. Barrier pixels and semantic labels change together.",
                "before_repair_false_offers": ["Transverse fence thickness 2, 3, and 5 map rows between the rear and putative point", "A frontage fence with a 10- or 18-row slit"],
                "after_held": {"transverse_barrier_map_rows": [2, 3, 5, 7, 9], "lateral_opening_map_rows": [0, 4, 7, 10, 18]},
                "after_offered": {"Original": [1973.3333333333333, 1961.501976284585], "35-row access opening": [1973.3333333333333, 1961.501976284585]},
            },
            "scope": "Synthetic and altered-pixel obstruction controls complement the unchanged photographic replay. They establish specific failure checks and cannot establish all weather, access or safety conditions.",
        },
        "observed_limitation": "A fresh manual through-road tap in the side-view white SUV scene was withheld with no relocation, although its explanation discussed the car angle. The separate automatic offer on the same photograph correctly identified the ground behind the SUV.",
        "screenshots_local": "runs/passenger-rear-20261124/development/rear-canonical-evidence-8775/",
        "archive": archive.name, "archive_sha256": check(archive.read_bytes()),
        "replay": "Extract methods/grade_live.py, methods/grade_browser.py and methods/review_third_open.py into the same directory, then run python review_third_open.py --replay <archive.zip>. Public source identifiers and attribution are in the earlier blind-evidence archive.",
    }
    output.write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + "\n", encoding="utf8")
    print(output.name, check(output.read_bytes()), archive.name, check(archive.read_bytes()))
