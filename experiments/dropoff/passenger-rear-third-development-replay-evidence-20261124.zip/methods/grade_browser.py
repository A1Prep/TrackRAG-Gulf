import hashlib, json, math, statistics, sys, zipfile
from datetime import datetime,timezone
from pathlib import Path
from collections import Counter

HERE=Path(__file__).resolve().parent
RUN=HERE.parent
ROOT=RUN.parent.parent
EXP=ROOT/'experiments/dropoff'
POLICY=['browser-primary','browser-revised-primary','browser-reserve','browser-primary-simple','browser-revised-simple']
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def iou(a,b):
    area=lambda v:max(0,v[2]-v[0])*max(0,v[3]-v[1])
    intersect=area([max(a[0],b[0]),max(a[1],b[1]),min(a[2],b[2]),min(a[3],b[3])])
    return intersect/(area(a)+area(b)-intersect) if intersect else 0.
def polygon_distance(p,poly):
    x,y=p; inside=False;nearest=math.inf
    for a,b in zip(poly,poly[1:]+poly[:1]):
        ax,ay=a;bx,by=b;dx=bx-ax;dy=by-ay
        t=max(0,min(1,((x-ax)*dx+(y-ay)*dy)/(dx*dx+dy*dy))) if dx or dy else 0.
        nearest=min(nearest,math.hypot(x-ax-t*dx,y-ay-t*dy))
        if (ay>y)!=(by>y) and x<(bx-ax)*(y-ay)/(by-ay)+ax:inside=not inside
    return nearest if inside else -nearest
def stats(vals):
    vals=sorted(vals)
    return {"n":len(vals),"min":min(vals),"median":statistics.median(vals),"max":max(vals)} if vals else {"n":0}
def body_measure(boxes,refs):
    best=[max((iou(b,g) for g in refs),default=0) for b in boxes]
    correct=sum(v>=.5 for v in best)
    kind=("unique_correct" if correct==1 and len(boxes)==1 else "correct_among_several" if correct
          else "wrong_only" if boxes else "none_shown")
    return {"classification":kind,"offered":len(boxes),"max_iou":round(max(best,default=0),4),"each_best_iou":[round(n,4) for n in best]}
def scored(obs,g,short):
    result=obs.get('result') or {}
    p=result.get('destination_point_xy')
    boxes=result.get('anchor_boxes_xyxy') or []
    grounded=body_measure(boxes,g['anchor_boxes_xyxy'])
    distances=[polygon_distance(p,polygon) for polygon in g['ground_polygons_xy']] if p else []
    choices=obs.get('choices') or []
    assert not choices, "Inspect the result choice schema separately before assigning an alternative"
    clear=g['eligible'];task=obs['task'];err=(obs.get('terminal')!='completed' or bool(obs.get('error')) or obs.get('state')=='error')
    direct=bool(p and obs.get('proposal') and obs.get('save_visible') and obs.get('state')=='proposed')
    clarified=(obs.get('state') in ('needs_clarification','insufficient_visual_evidence') and not p and not obs.get('proposal') and not obs.get('save_visible'))
    outcome=("operational_error" if err else
             "road_point_offered" if task=='lane' and direct else "road_tap_withheld" if task=='lane' and clarified else
             "direct_inside" if direct and distances and max(distances)>0 else
             "wrong_region" if direct and clear else "false_offer" if direct else
             "clear_withheld" if clarified and clear else "negative_withheld" if clarified else "unexpected_state")
    if direct and outcome in ('direct_inside','wrong_region','false_offer'):
        assert obs.get('save_verified'), "The direct output did not explicitly save the same point"
    tap=obs.get('actual_tap')
    if task=='lane' and not err: assert tap and math.dist(tap,g['lane_xy'])<.004*math.hypot(*g['size'])
    return {"id":g['id'],"task":task,"eligible":clear,"shortened_ambiguous":short if task=='natural' else None,
            "outcome":outcome,"anchor":grounded,"point":p,
            "signed_distance_to_nearest_valid_polygon_px":round(max(distances),2) if distances else None,
            "separately_selectable_alternatives":len(choices),"explicit_save_replayed":bool(obs.get('save_verified')),
            "observed_tap":([round(v,2) for v in tap] if tap else None),"browser_ms":obs.get('visible_ms'),
            "recovery_error":obs.get('error') or obs.get('problem'),"browser_errors":obs.get('browser_errors') or []}
def grade(name, archive=None):
    def artifact_disk_or_zip(disk, entry):
        return disk.read_bytes() if archive is None else archive.read(entry)
    byte_hash=lambda b:hashlib.sha256(b).hexdigest()
    source=artifact_disk_or_zip(RUN/name/'observations.json','browser_outputs/'+name+'/observations.json')
    d=json.loads(source)
    assert d.get('finished_utc')
    cohort='reserve' if name=='browser-reserve' else 'primary'
    req='primary-simple-requests.json' if 'simple' in name else cohort+'-requests.json'
    def load_field(fn,section):
        return artifact_disk_or_zip(HERE/fn,section+'/'+fn)
    orig=load_field(cohort+'-reference.json','independent_reference')
    seal=json.loads(load_field(cohort+'-seal.json','independent_reference'))
    assert byte_hash(orig)==seal['sha256']['reference']
    if archive is None:
        assert digest(HERE/(cohort+'-sources.json'))==seal['sha256']['sources']
    assert byte_hash(load_field(req,'blind_inputs'))==d['requests_sha256']
    assert byte_hash(load_field(cohort+'-taps.json','blind_inputs'))==d['taps_sha256']
    gold={r['id']:r for r in json.loads(orig)['cases']}
    if archive is not None:
        for source_row in json.loads(archive.read('public_sources/'+cohort+'.json')):
            g=gold[source_row['id']]
            assert all(g[k]==source_row[k] for k in ('recording_id','frame_id','sha256','size'))
    short={g['id']:g['multiple_plausible_after_shortening'] for g in json.loads(load_field('primary-simple-ambiguity.json','independent_reference'))['cases']} if 'simple' in name else {}
    rows=[]
    for row in d['rows']:
        g=gold[row['id']];assert row['sha256']==g['sha256']
        rows.append(scored(row,g,short.get(row['id'])))
    tasks=('natural',) if short else ('natural','lane')
    assert {(r['id'],r['task']) for r in rows}=={(i,t) for i in gold for t in tasks}
    natural=[r for r in rows if r['task']=='natural']; lanes=[r for r in rows if r['task']=='lane']
    sm={"natural_eligible":sum(r['eligible'] for r in natural),"natural_ineligible":sum(not r['eligible'] for r in natural),
        "natural_outcomes":dict(Counter(r['outcome'] for r in natural)),
        "natural_vehicle_outlines":dict(Counter(r['anchor']['classification'] for r in natural)),
        "natural_vehicle_outlines_on_eligible":dict(Counter(r['anchor']['classification'] for r in natural if r['eligible'])),
        "natural_suggested_alternatives":sum(r['separately_selectable_alternatives'] for r in natural),
        "correct_direct_and_unique_correct_vehicle":sum(r['outcome']=='direct_inside' and r['anchor']['classification']=='unique_correct' for r in natural),
        "explicit_saves":sum(r['explicit_save_replayed'] for r in natural),
        "natural_browser_ms":stats([r['browser_ms'] for r in natural if r['browser_ms'] is not None]),
        "lane_outcomes":dict(Counter(r['outcome'] for r in lanes)),"lane_browser_ms":stats([r['browser_ms'] for r in lanes if r['browser_ms'] is not None]),
        "browser_error_events":sum(len(r['browser_errors']) for r in rows)}
    if short:
        sm['genuinely_ambiguous_when_shortened']=[r['id'] for r in natural if r['shortened_ambiguous']]
        sm['ambiguous_outcomes']=dict(Counter(r['outcome'] for r in natural if r['shortened_ambiguous']))
        sm['unambiguous_outcomes']=dict(Counter(r['outcome'] for r in natural if not r['shortened_ambiguous']))
    return {"commit":d['candidate'],"completed_utc":d['finished_utc'],"browser_output_sha256":byte_hash(source),
            "question_input_sha256":d['requests_sha256'],"tap_input_sha256":d['taps_sha256'],"prelabelled_reference_sha256":byte_hash(orig),
            "summary":sm,"rows":rows}
if __name__=='__main__':
    if len(sys.argv)==3 and sys.argv[1]=='--replay':
        with zipfile.ZipFile(sys.argv[2]) as z:
            print(json.dumps({name:grade(name,z) for name in POLICY},indent=2))
        sys.exit(0)
    # Finish all browser artifacts before opening and scoring the reserved images.
    assert all(read(RUN/p/'observations.json').get('finished_utc') for p in POLICY)
    arms={p:grade(p) for p in POLICY}
    for p,arm in arms.items():print(p,json.dumps(arm['summary']))
    print('unique_target',[(r['id'],r['anchor']['classification'],r['anchor']['max_iou']) for r in arms['browser-reserve']['rows'] if r['task']=='natural'])
    print('same points pairs',[[a['id'],a['outcome'],b['outcome'],a['point']==b['point']] for a,b in zip(arms['browser-revised-primary']['rows'][:8],arms['browser-revised-simple']['rows'])])
    archive=EXP/'passenger-rear-field-browser-evidence-20261124.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for a in POLICY:z.write(RUN/a/'observations.json','browser_outputs/'+a+'/observations.json')
        for fn in ['primary-requests','reserve-requests','primary-simple-requests','primary-taps','reserve-taps']:
            z.write(HERE/(fn+'.json'),'blind_inputs/'+fn+'.json')
        for fn in ['primary-seal','reserve-seal','primary-reference','reserve-reference','primary-simple-ambiguity']:
            z.write(HERE/(fn+'.json'),'independent_reference/'+fn+'.json')
        for key in ('primary','reserve'):
            sources=read(HERE/(key+'-sources.json'))['sources']
            view=[{k:r[k] for k in ('id','recording_id','frame_id','size','sha256','source_url','captured','lat','lng','attribution','license','license_url','source_terms','original_blur_status')} for r in sources]
            z.writestr('public_sources/'+key+'.json',json.dumps(view,indent=2,ensure_ascii=False))
        z.write(RUN/'field-browser.cjs','methods/field-browser.cjs')
        z.write(Path(__file__),'methods/grade_browser.py')
    result={"reviewer":"Independent AI visual reviewer. Publisher-blurred original images were inspected and annotated before any model predictions. No human performance or driving-safety claim is measured.",
            "population":"Fourteen UAE driver-view images on fourteen distinct previously unevaluated recording sequences. The primary eight were used to improve the revised method after the baseline. Only the untouched six evaluate transfer of that revision. These are purposively balanced small samples.",
            "measurement":{"direct":"A native destination pin strictly inside any separately frozen polygon, with a visible Save control and the same two-dimensional point after explicit browser confirmation. A wrong-location pin on a positive is measured separately. A lack of an offer on a negative is appropriate only when completed without operational failure.",
            "alternatives":"Separately selectable alternate areas would be distinguished from an automatic destination. No first turn rendered an alternative list in these five arms.",
            "vehicle":"Diagnostic body matching uses native box intersection-over-union >= 0.50. A unique correct outline, the intended body among extra outlines, a wrong-only outline, and no outline are separate. This diagnostic threshold was set for scoring; polygon-inclusion was preregistered before model outputs.",
            "road":"The browser submitted one preregistered through-road point from a clean session, using the visible real-image marking controls. Each actual source point was checked within 0.4% of the native image diagonal of its intended tap. A withheld road test supplies zero automatic parking positives.",
            "time":"Wall-clock milliseconds from submit to visible terminal response; timing excludes loading the photo, preparing sources, and the human action to save. Median and range are supplied because cohorts are small.",
            "short":"The same eight photos and physical references were tested with shorter questions fixed before the original runs. Two questions lose a positional disambiguator; offering their intended location by coincidence does not prove resolution of the shorter ambiguous language."},
            "evidence_archive":archive.name,"evidence_archive_sha256":digest(archive),
            "reproduce":"Extract methods/grade_browser.py from the ZIP, then run python grade_browser.py --replay <path-to-the-ZIP>. Python's standard library can recompute each case, the role of its anchor, signed pixel distance, first-turn latency and arm summaries without model access. Source photos are attributed separately inside public_sources.",
            "arms":arms}
    (EXP/'passenger-rear-field-browser-results-20261124.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf8')

